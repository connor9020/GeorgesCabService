package com.georgescabservice.cab_fare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabFareApplication {

	public static void main(String[] args) {
		SpringApplication.run(CabFareApplication.class, args);
	}

}
